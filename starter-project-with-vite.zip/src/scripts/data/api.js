import CONFIG from "../config";

const ENDPOINTS = {
  REGISTER: `${CONFIG.BASE_URL}/register`,
  LOGIN: `${CONFIG.BASE_URL}/login`,
  STORIES: `${CONFIG.BASE_URL}/stories`,
  STORY_DETAIL: (id) => `${CONFIG.BASE_URL}/stories/${id}`,
};

export async function register(name, email, password) {
  const url = `${CONFIG.BASE_URL}/register`;

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ name, email, password }),
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || "Failed to register");
  }

  return response.json();
}

export async function login(email, password) {
  try {
    const response = await fetch(ENDPOINTS.LOGIN, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    });

    const responseJson = await response.json();
    console.log("Login response:", responseJson);

    if (!response.ok) {
      throw new Error(responseJson.message || "Failed to login");
    }

    const { loginResult } = responseJson;
    if (
      !loginResult ||
      !loginResult.token ||
      !loginResult.token.includes(".")
    ) {
      throw new Error("Invalid token format");
    }

    localStorage.setItem("token", loginResult.token);
    console.log("Token saved to localStorage:", loginResult.token);

    return loginResult;
  } catch (error) {
    console.error("Login error:", error.message);
    throw error;
  }
}

export async function getAllStories(page = 1, size = 10, location = 0, token) {
  const response = await fetch(
    `${ENDPOINTS.STORIES}?page=${page}&size=${size}&location=${location}`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
  return await response.json();
}

export async function addStory(description, photo, token, lat, lon) {
  try {
    const formData = new FormData();
    formData.append("description", description);
    formData.append("photo", photo);

    if (lat) formData.append("lat", lat);
    if (lon) formData.append("lon", lon);

    const response = await fetch(ENDPOINTS.STORIES, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Server returned: ${errorText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Error in addStory:", error);
    throw error;
  }
}
