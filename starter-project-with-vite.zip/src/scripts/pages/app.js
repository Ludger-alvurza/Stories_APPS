class App {
  #content = null;
  #drawerButton = null;
  #navigationDrawer = null;

  constructor({ navigationDrawer, drawerButton, content }) {
    this.#content = content;
    this.#drawerButton = drawerButton;
    this.#navigationDrawer = navigationDrawer;

    this.#setupDrawer();
    this.#updateNavbar();
  }

  #setupDrawer() {
    this.#drawerButton.addEventListener("click", () => {
      this.#navigationDrawer.classList.toggle("open");
    });

    document.body.addEventListener("click", (event) => {
      if (
        !this.#navigationDrawer.contains(event.target) &&
        !this.#drawerButton.contains(event.target)
      ) {
        this.#navigationDrawer.classList.remove("open");
      }

      this.#navigationDrawer.querySelectorAll("a").forEach((link) => {
        if (link.contains(event.target)) {
          this.#navigationDrawer.classList.remove("open");
        }
      });
    });
  }

  #updateNavbar() {
    const token = localStorage.getItem("authToken");
    const loginLink = this.#navigationDrawer.querySelector('a[href="#/login"]');

    if (token && loginLink) {
      try {
        loginLink.textContent = "Anda sudah login";
      } catch (error) {
        console.error("Invalid token:", error);
        loginLink.textContent = "Login";
      }
    } else if (!token && loginLink) {
      loginLink.textContent = "Login";
    }
  }
}

export default App;
