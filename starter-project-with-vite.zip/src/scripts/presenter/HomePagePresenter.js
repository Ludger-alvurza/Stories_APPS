import { getAllStories } from "../data/api.js";

export default class HomePagePresenter {
  constructor(view) {
    this.view = view;
  }

  async loadStories() {
    const token = localStorage.getItem("authToken");

    if (!token) {
      this.view.displayMessage("<p>Please log in to see the stories.</p>");
      return;
    }

    try {
      const page = 1;
      const size = 10;
      const location = 0;
      const response = await getAllStories(page, size, location, token);

      if (response.error) {
        this.view.displayMessage(`<p>Error: ${response.message}</p>`);
        return;
      }

      if (response.listStory.length === 0) {
        this.view.displayMessage("<p>No stories available.</p>");
        return;
      }

      const storiesHtml = response.listStory
        .map((story, index) => this.view.createStoryHTML(story, index))
        .join("");

      this.view.displayStories(storiesHtml);

      response.listStory.forEach((story, index) => {
        if (story.lat && story.lon) {
          this.view.initializeMap(
            index,
            story.lat,
            story.lon,
            story.name,
            story.description
          );
        }
      });
    } catch (error) {
      this.view.displayMessage(
        `<p>Error fetching stories: ${error.message}</p>`
      );
    }
  }
}
